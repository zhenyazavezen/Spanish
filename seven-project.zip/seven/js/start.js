// Запуск тренировки из любого места приложения.
import * as router from './router.js';
import { activeSession } from './store.js';
import { confirmDialog } from './ui.js';
import { unlockAudio } from './feedback.js';
import { t } from './i18n.js';

export async function startPlan(plan) {
  if (activeSession.get()) {
    const ok = await confirmDialog({ title: t('start.replaceTitle'), text: t('start.replaceText'), confirm: t('start.replaceConfirm'), danger: true });
    if (!ok) return;
    activeSession.clear();
  }
  unlockAudio();                                    // звук разрешается только после нажатия
  router.go('player', { plan });
}
