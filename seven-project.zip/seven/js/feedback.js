// Короткие звуки и вибрация. Голоса тренера в первой версии нет — только лёгкие сигналы.
import { settings } from './store.js';
import { tg } from './tg.js';

let ctx = null;

/** Вызывать из обработчика нажатия: мобильные браузеры разрешают звук только после жеста. */
export function unlockAudio() {
  try {
    ctx ||= new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
  } catch { ctx = null; }
}

function tone(freq, dur, vol = 0.16, delay = 0) {
  if (!ctx) return;
  const t = ctx.currentTime + delay;
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = 'sine'; o.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(ctx.destination);
  o.start(t); o.stop(t + dur + 0.02);
}

export function beep(kind) {
  if (!settings.get().sound) return;
  unlockAudio();
  if (kind === 'tick') tone(880, 0.1);
  else if (kind === 'go') { tone(1175, 0.16, 0.2); }
  else if (kind === 'done') { tone(880, 0.14); tone(1175, 0.14, 0.18, 0.16); tone(1568, 0.3, 0.18, 0.32); }
}

export function haptic(kind = 'light') {
  if (!settings.get().haptics) return;
  if (!tg.haptic(kind)) { try { navigator.vibrate?.(kind === 'success' ? [20, 40, 20] : 12); } catch { /* ignore */ } }
}
