// Единая точка настройки приложения. Всё, что может поменяться при публикации, — здесь.
export const CONFIG = {
  appName: 'SEVEN',
  version: '0.1.0',
  // Языки, которые видит пользователь. Чтобы добавить украинский:
  // 1) locales/uk.json  2) data/content.uk.json  3) добавить 'uk' сюда (см. README).
  enabledLangs: ['ru'],
  defaultLang: 'ru',
  // Куда ведёт «Написать в поддержку». Замените на свой чат, когда он появится.
  supportUrl: 'https://t.me/zhenya_zavezen_bot',
  storePrefix: 'seven:',
};

export const BUILD = (typeof document !== 'undefined' && document.querySelector('meta[name="build"]')?.content) || 'dev';
