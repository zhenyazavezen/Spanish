# Notice

SEVEN is built on ideas and selected logic from "Workout Coach" by Ashwin Raghavan
(https://github.com/ashwinr93/workout), MIT License, Copyright (c) 2026 Ashwin Raghavan.
The original licence text is kept in LICENSE and must stay with any copy of that code.
The original repository is not modified. SEVEN's interface, media and branding are original.
